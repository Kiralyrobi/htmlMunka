export const honapok=[
    {
        name: "szeptember",
        evszak: "osz",
        photoUrl: "./img/szeptember.jpg",
        leiras: "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
    },
    {
        name: "október",
        evszak: "osz",
        photoUrl: "./img/oktober.jpg",
        leiras: "In sodales lobortis venenatis."
    },
    {
        name: "november",
        evszak: "osz",
        photoUrl: "./img/november.jpg",
        leiras: "Fusce sodales diam volutpat nulla finibus vulputate."
    },
    {
        name: "december",
        evszak: "tel",
        photoUrl: "./img/december.jpg",
        leiras: "Fusce dui enim, consequat ac auctor sit amet, mattis eget odio."
    },
    {
        name: "január",
        evszak: "tel",
        photoUrl: "./img/januar.jpg",
        leiras: "Morbi venenatis hendrerit diam, sit amet feugiat nisi convallis eu."
    },
    {
        name: "február",
        evszak: "tel",
        photoUrl: "./img/februar.jpg",
        leiras: "Nunc auctor augue nec accumsan lacinia."
    },
    {
        name: "március",
        evszak: "tavasz",
        photoUrl: "./img/marcius.jpg",
        leiras: "Pellentesque aliquam luctus eros a tincidunt."
    },
    {
        name: "április",
        evszak: "tavasz",
        photoUrl: "./img/aprilis.jpg",
        "eiras": "Vivamus dolor turpis, lobortis eu sagittis sit amet, posuere nec justo."
    },
    {
        name: "május",
        evszak: "tavasz",
        photoUrl: "./img/majus.jpg",
        leiras: "Sed volutpat tortor sed nunc blandit, vel rutrum erat rhoncus."
    },
    {
        name: "június",
        evszak: "nyar",
        photoUrl: "./img/junius.jpg",
        leiras: "Nulla erat enim, lobortis et metus vitae, porttitor pharetra arcu."
    },
]